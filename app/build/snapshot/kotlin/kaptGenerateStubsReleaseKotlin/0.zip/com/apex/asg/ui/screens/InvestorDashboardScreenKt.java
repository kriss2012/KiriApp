package com.apex.asg.ui.screens;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000 \n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\u001a\u0012\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u0007\u001a\u0010\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0006H\u0007\u001a\u0018\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\tH\u0007\u00a8\u0006\u000b"}, d2 = {"InvestorDashboardScreen", "", "vm", "Lcom/apex/asg/ui/viewmodels/InvestorViewModel;", "InvestorPitchCard", "pitch", "Lcom/apex/asg/data/remote/InvestorPitchDto;", "TrendBox", "label", "", "value", "app_release"})
public final class InvestorDashboardScreenKt {
    
    @androidx.compose.runtime.Composable()
    public static final void InvestorDashboardScreen(@org.jetbrains.annotations.NotNull()
    com.apex.asg.ui.viewmodels.InvestorViewModel vm) {
    }
    
    @androidx.compose.runtime.Composable()
    public static final void TrendBox(@org.jetbrains.annotations.NotNull()
    java.lang.String label, @org.jetbrains.annotations.NotNull()
    java.lang.String value) {
    }
    
    @androidx.compose.runtime.Composable()
    public static final void InvestorPitchCard(@org.jetbrains.annotations.NotNull()
    com.apex.asg.data.remote.InvestorPitchDto pitch) {
    }
}