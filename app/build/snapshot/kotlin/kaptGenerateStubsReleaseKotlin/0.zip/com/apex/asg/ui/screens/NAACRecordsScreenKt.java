package com.apex.asg.ui.screens;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000 \n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\u0012\u0010\u0000\u001a\u00020\u00012\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u0007\u001a2\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\nH\u0007\u00f8\u0001\u0000\u00a2\u0006\u0004\b\u000b\u0010\f\u0082\u0002\u0007\n\u0005\b\u00a1\u001e0\u0001\u00a8\u0006\r"}, d2 = {"NAACRecordsScreen", "", "vm", "Lcom/apex/asg/ui/viewmodels/NAACViewModel;", "RecordCard", "title", "", "date", "status", "statusColor", "Landroidx/compose/ui/graphics/Color;", "RecordCard-g2O1Hgs", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V", "app_release"})
public final class NAACRecordsScreenKt {
    
    @androidx.compose.runtime.Composable()
    public static final void NAACRecordsScreen(@org.jetbrains.annotations.NotNull()
    com.apex.asg.ui.viewmodels.NAACViewModel vm) {
    }
}