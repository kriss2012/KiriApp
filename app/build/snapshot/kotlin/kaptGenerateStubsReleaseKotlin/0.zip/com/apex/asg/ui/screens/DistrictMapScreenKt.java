package com.apex.asg.ui.screens;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\b\n\u0000\n\u0002\u0010\u0002\n\u0000\u001a\b\u0010\u0000\u001a\u00020\u0001H\u0007\u00a8\u0006\u0002"}, d2 = {"DistrictMapScreen", "", "app_release"})
public final class DistrictMapScreenKt {
    
    @androidx.compose.runtime.Composable()
    public static final void DistrictMapScreen() {
    }
}