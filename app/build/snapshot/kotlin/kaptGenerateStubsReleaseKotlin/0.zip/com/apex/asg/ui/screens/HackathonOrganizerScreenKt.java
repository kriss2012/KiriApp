package com.apex.asg.ui.screens;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u0018\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\u001a\b\u0010\u0000\u001a\u00020\u0001H\u0007\u001a \u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0006H\u0007\u00a8\u0006\b"}, d2 = {"HackathonOrganizerScreen", "", "StepIndicator", "number", "", "isCompleted", "", "isActive", "app_release"})
public final class HackathonOrganizerScreenKt {
    
    @androidx.compose.runtime.Composable()
    public static final void HackathonOrganizerScreen() {
    }
    
    @androidx.compose.runtime.Composable()
    public static final void StepIndicator(@org.jetbrains.annotations.NotNull()
    java.lang.String number, boolean isCompleted, boolean isActive) {
    }
}